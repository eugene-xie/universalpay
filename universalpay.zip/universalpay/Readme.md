

This is a fork from: https://github.com/prestalab/universalpay

I made it work on prestashop 1.7.4.2


Just download the zip, extract, rename the project folder to universalpay and make an archive universalpay.zip



With this module, you can create an unlimited number of payment methods without writing separate modules.

Features : Creates an unlimited number of fully customizable methods of payment Allows you to bind to a payment to carrier It does not require programming skills
